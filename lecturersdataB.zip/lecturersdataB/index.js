const express = require("express");
const app = express();
const port = 3288;
const lecturersRoutes = require('./controllers/lecturersController');

// Middleware to parse JSON requests
app.use(express.json());

// Lecturers routes
app.use('/lecturers', lecturersRoutes);

// Global error handler
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({ message: 'Something went wrong!' });
});

// Start the server
app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});