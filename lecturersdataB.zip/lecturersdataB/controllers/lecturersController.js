const express = require('express');
const router = express.Router();
const db = require('../models/db');

// GET /dosen
router.get('/', (req, res) => {
    db.query('SELECT * FROM dosen', (error, results) => {
        if (error) {
            console.error('Database query error:', error);
            return res.status(500).json({ message: 'Internal Server Error', error: error.message });
        }
        res.json(results);
    });
});

// GET /dosen/:id
router.get('/:id', (req, res) => {
    const id = req.params.id;
    db.query('SELECT * FROM dosen WHERE id = ?', [id], (error, results) => {
        if (error) {
            console.error('Database query error:', error);
            return res.status(500).json({ message: 'Internal Server Error', error: error.message });
        }
        if (results.length === 0) {
            return res.status(404).json({ message: 'Dosen not found' });
        }
        res.json(results[0]);
    });
});

// POST /dosen
router.post('/', (req, res) => {
    const { id, nama, gender, prodi, alamat } = req.body;
    db.query('INSERT INTO dosen (id, nama, gender, prodi, alamat) VALUES (?, ?, ?, ?, ?)',
      [id, nama, gender, prodi, alamat],
      (error, results) => {
          if (error) {
              console.error('Database insert error:', error);
              return res.status(500).json({ message: 'Internal Server Error', error: error.message });
          }
          res.status(201).json({ message: 'Dosen added successfully', id: results.insertId });
      }
    );
});

// PUT /dosen/:id
router.put('/:id', (req, res) => {
    const id = req.params.id;
    const { nama, gender, prodi, alamat } = req.body;
    db.query('UPDATE dosen SET nama = ?, gender = ?, prodi = ?, alamat = ? WHERE id = ?',
      [nama, gender, prodi, alamat, id],
      (error) => {
          if (error) {
              console.error('Database update error:', error);
              return res.status(500).json({ message: 'Internal Server Error', error: error.message });
          }
          res.json({ message: 'Dosen updated successfully' });
      }
    );
});

// DELETE /dosen/:id
router.delete('/:id', (req, res) => {
    const id = req.params.id;
    db.query('DELETE FROM dosen WHERE id = ?', [id], (error) => {
        if (error) {
            console.error('Database delete error:', error);
            return res.status(500).json({ message: 'Internal Server Error', error: error.message });
        }
        res.json({ message: 'Dosen deleted successfully' });
    });
});

module.exports = router;